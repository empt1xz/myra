(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_react-icons_fa6_index_mjs_79da82bd._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_8ac33fe4._.js",
  "static/chunks/src_183eddd4._.js",
  "static/chunks/src_components_landing_transition_module_a0fa5d69.css"
],
    source: "dynamic"
});
