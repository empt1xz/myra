import type { Metadata } from "next";
import "./globals.css";
import { ThemeProvider } from 'next-themes'

export const metadata: Metadata = {
  title: "Myra Bot",
  description: "Descrição",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-br" suppressHydrationWarning>
      <body >
        <ThemeProvider attribute={'class'} defaultTheme="system" enableSystem>
        {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
